package com.th;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRest3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
