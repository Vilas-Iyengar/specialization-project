package com.th.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Groceries {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int proid;
	private String categories;
	private String proname;
	private int quantity;
	private int price;
	private byte[] image;
	
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public int getProid() {
		return proid;
	}
	public void setProid(int proid) {
		this.proid = proid;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public String getProname() {
		return proname;
	}
	public void setProname(String proname) {
		this.proname = proname;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int i) {
		this.quantity = i;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Groceries [proid=" + proid + ", categories=" + categories + ", proname=" + proname + ", quantity="
				+ quantity + ", price=" + price + "]";
	}
	
	public Groceries(int proid, String categories, String proname, int quantity, int price, byte[] image) {
		super();
		this.proid = proid;
		this.categories = categories;
		this.proname = proname;
		this.quantity = quantity;
		this.price = price;
		this.image = image;
	}
	public Groceries() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	
	
}