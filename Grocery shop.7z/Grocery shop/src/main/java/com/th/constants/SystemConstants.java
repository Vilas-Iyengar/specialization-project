package com.th.constants;

public class SystemConstants {
	
	public static final String FRUIT = "fruit";

}
